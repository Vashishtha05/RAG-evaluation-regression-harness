# RAG Evaluation & Regression Harness

This project treats RAG quality as a testable software contract. It keeps **retrieval scores** separate from **generation scores**, so a failing answer can be diagnosed as a retrieval problem or a generation problem.

## Build order

1. Golden dataset: verified questions, retrieval labels, expected answers, and source context.
2. Swappable RAG pipeline: chunking, embeddings, vector store, retrieval, and generation behind interfaces.
3. Deterministic retrieval metrics: Precision@k, Recall@k, and MRR.
4. LLM judges: faithfulness, answer relevance, and hybrid correctness.
5. Judge calibration against human labels.
6. SQLite results store.
7. Baselines, diffs, thresholds, and regression gates.
8. Pull-request CI gate and nightly full evaluation.
9. Streamlit dashboard.

## Quick start

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -e ".[runtime,dev]"
pytest
python -m rag_eval.cli validate-dataset
```

The initial corpus is the public-domain Constitution of the United States. The golden set holds 50 cases (48 verified) mixing single-chunk factual questions, multi-chunk questions, and deliberately unanswerable questions. `verified` marks the trustworthy human-reviewed core; future generated candidates must not be promoted into that subset without review.

To run the quality gate locally, persist the candidate run, and write a Markdown report:

```powershell
python -m rag_eval.cli evaluate --store results.sqlite3 --run-id local --baseline-file data/baseline.json --threshold 0.05 --report-file rag-quality-report.md
```

Use `--vector-store vector` for the deterministic embedding backend, `--vector-store faiss` after installing `.[vector]`, or `--llm openai:gpt-4o-mini --embedding-model openai:text-embedding-3-small` with an OpenAI key. Prompt templates are selected with `--prompt-template`. Pull requests evaluate 10 verified cases; the scheduled workflow evaluates the complete golden set.

The quality gate is independent of persistence: it runs whenever a baseline is supplied (`--baseline-file` for a standalone baseline, or `--baseline <run-id>` together with `--store` to read a saved run), and it exits non-zero on any metric drop beyond `--threshold`. `--store` only controls whether the candidate run is written to SQLite.

## Judge calibration

Calibrate a judge against the human labels in `data/calibration.json` and report per-metric agreement:

```powershell
python -m rag_eval.cli calibrate --judge heuristic
python -m rag_eval.cli calibrate --judge openai:gpt-4o-mini   # the judge you actually ship (needs the llm extra + key)
```

The heuristic judge is deterministic and needs no key; calibrate the OpenAI judge before trusting its scores, since its human agreement is the number that decides whether the gate is measuring quality or noise.

## Regression thresholds from variance

A flat `--threshold` treats every metric as equally stable, but LLM-judged metrics wobble run to run while deterministic retrieval metrics do not. Derive a per-metric tolerance from the spread of repeated same-config runs, then gate against it:

```powershell
python -m rag_eval.cli suggest-thresholds --store results.sqlite3 --runs run-a,run-b,run-c --z 2 --out data/thresholds.json
python -m rag_eval.cli evaluate --baseline-file data/baseline.json --threshold-file data/thresholds.json
```

`--threshold-file` overrides `--threshold` per metric, so a naturally noisy metric gets a wider band while a stable one keeps a tight one.

## Metrics

Metrics are averaged only over the cases where they are meaningful, so the three families never dilute one another:

- **Retrieval** (Precision@k, Recall@k, MRR) is scored over *answerable* cases only. Unanswerable cases have no relevant chunk to find, so folding them in would produce a degenerate recall of 1.0 and precision of 0.0.
- **Abstention** is scored over *unanswerable* cases only: 1.0 when the pipeline declines to answer from the corpus, 0.0 when it over-answers. The default offline answerer never abstains, so its baseline abstention is 0.0; an LLM answerer that honors the context-first prompt is what raises it.
- **Generation** (faithfulness, answer relevance, correctness) is scored over every case.

Because the sets differ, `data/baseline.json` (full golden set) carries an `abstention` score while `data/baseline-pr.json` (first 10 verified cases, all answerable) does not.

## Project layout

- `data/corpus/`: source documents and chunk manifests.
- `data/golden.json`: versioned evaluation cases.
- `src/rag_eval/`: the package, built component by component.
- `tests/`: focused checks for each component.
- `.github/workflows/`: fast pull-request evaluation and full nightly evaluation.

## License

Released under the MIT License. See `LICENSE`.